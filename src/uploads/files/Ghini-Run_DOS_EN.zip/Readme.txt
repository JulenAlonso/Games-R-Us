 gggp   _ggggga   ggg      ,ggp           pgg=      pggggggg,                   
 Q##^ ,########_ ,##@      I##P           ##B       ########B                   
 ##@ ,M##@"9###9 &##C      "                       l##B""@##B                   
 ##" @##P   ""   W##2###a ,ggp /ggpg##g  pgg*      A##@  &##@ pgg* qgg^ gggg##b,
    /##@  ____, )#######@ I##P Q##M####  ##B       ###Ggd###  ##B  ##B l##B####L
    W##C l####@ ###M"@##C W##  ##B"7##B l##@      l#######@  l##@ l##@ Q##@"###\
   ,###  0####L M#B  ##B ,##@ [##@ [##@ A##L      A##@M###,  A##L Q##Y ##M  ##B 
   ]###,   ##B )##@ j##@ I##P Q##^ W##^ ##B       ###L]###@  ##B ,##B l##@ /##@ 
    ###@ggM##@ ###C A##C W##  ##B ,##B l##@      l##B  ###@ {##Bg@##@ Q##Y Q##Y 
    Q######B"  M#B  ##B ,##@ [##@ I##@ A##L      A##@  B##B {####@##Y ##B  ##B  
     ""44""    """  """ '""" """^ """^ """       """"  """"  ^'""""" `""" `"""  

'GHINI RUN * Marcus Kasumba 2002 * piptol@yahoo.com * http://piptol.cjb.net

=================================================================================
THE GAME:
Fill up the tank, buff the bodywork to a chromium shine and hear that V12 purrr
like a kitten. It's time once again for the SHOTGUN RUN - an illegal race across
several demanding courses, where every twist and turn of the track will test your
nerve, not to mention suspension! Through the sun-kissed beaches of Bluewater,
floor-it past the ancient castle ruins with bearly a moment to admire the scenery
before screaming through the streets of St. George, after sundown. Head south
past the sub-tropical lagoons, whilst trying to keep your supercar from becoming
a permanent fixture of the landscape! Only the hardened drivers continue past this
point, ascending the dangerous road through the Azure Falls, where the sane finish
at Bow Bridge. Only the insane and the fearless head onward to the wild, blizzard-
lashed mountains for the final, ultimate prize..

=================================================================================
Please run SETUP.EXE prior to running GHINI RUN for the first time.
=================================================================================
IN-GAME

MENU:
In the menus, press ACCELERATE to accept or BRAKE to cancel

RACE:
	ARCADE 		- Single race on the track of your choice, with AI cars
	SHOTGUN RUN 	- 4, 5 or 6 race tournament. Finish 1st-3rd to qualify
	TIME ATTACK	- Free run on any (unlocked) track
	PURSUIT		- Play as the police and take those 'runners off the road!

DRIVER	- Change driver name

RECORDS - View the best of the best. You can scroll the scores up and down.

OPTIONS:
	LEVEL	- Difficulty setting, affects no. of AI opponents & time allowed
	SPEED	- Want to play faster? Notch up the gamespeed here
	VSYNC	- A, B or OFF. Experiment to find the best setting for your PC
	SFX LAG - Changing this to HIGH *might* fix some sound-crash problems

CREDITS - Who did what
QUIT	- Exit 'Ghini Run

=================================================================================
PLAYING THE GAME
Accelerate, brake, steer left & right. How simple do you want it to be? :-)
=================================================================================
GAME ISSUES:
Q) How do I unlock the last 3 tracks?
A) Complete the 'Shotgun Run' game. 'Rookie' mode unlocks Sunset Lagoon, 'Normal'
and 'Pro' open up 'Azure Falls' and 'Wild Ice Road' respectively.

Q) How do I unlock the extra cars?
A) Finish pursuit mode in 1st place. You must do each track in order..

Q) (Insert problem here) occurs when I play with sound enabled
A) The sound engine is a customised version of DS4QB++, which provides access of
Windows sound resources from DOS programs. It's not perfect however, and problems
can occur ranging from the occasional music-pop to a full blown crash. If you have
major problems, simply disable sound in SETUP.

Q) I get a warning that the game is running without EMS memory
A) Ghini Run will run without EMS. However, it is highly desirable that you
enable EMS memory to get the most out of the game.

Q) How do I set up EMS memory?
A) Windows can handle this for you; best way I've found is simply to remove
the EMM386.EXE driver from autoexec.bat. Otherwise, you want something like this:

		DEVICE=<path>\HIMEM.SYS
                DEVICE=<path>\EMM386.EXE RAM H=255

Or..
In Windows, right click on GHINI.EXE, go to 'properties' and enable Expanded (EMS)
memory through that. (e.g. In Win95 it's on the 'Memory' tab)

Q) Can I run in pure DOS mode?
A) Yes, but make sure you disable the sound first in SETUP.

Q) The game crashed with a 'Permission denied'/'File not found' error!
A) It's an unfortunate problem with the sound engine that is beyond my control.
On the plus side, it's a pretty rare occurance. If it happens, return to Windows
and end tasks 'ds4qbxx' and 'ghini'. Then you've got to reload :-/

Q) Wow, what a cool game, can I distribute it on my website!?
A) This game is freeware and you are free to make copies of it and distribute it
   as you wish, so please do :) No money may be charged for this game.
=================================================================================
FOOTNOTE
"This game is a tribute to Outrun. Released by Sega in 1986, the first decent
driving game since 'Pole Position 2'. It was absolutely awesome, and you never
forgot the first time you played it; truely a defining moment in gaming youth.
Only a handful of games ever have had that touch of '1st time magic'."

"Could I ever hope to recreate the magic of Outrun in QuickBasic? No. Never. But
I'll stick my pennies in the gumball machine and see what I get out of it..."

- Marcus Kasumba

=================================================================================
HISTORY
'Ghini Run v1.2
Released 02 January 2003
- Was Azure Falls actually possible on PRO? Now you have a chance: more time!
=================================================================================
'Ghini Run v1.11
Released 24 September 2002
- Due to popular request, lots more time in Pursuit mode. Enjoy!
=================================================================================
'Ghini Run v1.1
Released 16 June 2002

- Pause key added
- Sound lag setting added - if you get many 'permission denided'or 'file not
  found' crashes, try setting it to high.
- New music when game completed
- Extra end screen when you finish 'Pro' mode
- Minor graphical improvements
- Some extra sound effects
- Repeated bumps will result in a crash, so you wont get 'stuck' against scenery
- AI cars drive a fairer race
- Effect of hills on your speed is not so drastic
- More generous time limits
=================================================================================
'Ghini Run v1.0
Released 08 May 2002
- First official full release
=================================================================================
'Ghini Run v0.81
Released 19 March 2001
- Fixed a bug which prevented the track times being saved properly
- Track times now display correctly (on menu screen)
=================================================================================
'Ghini Run v0.8
Released 11 March 2001

So what's new?
- Improved graphics.. the cars now turn!
- Improved car handling & acceleration
- Other cars *can* be run of the road!
- Gear & speedo indicators added
- Position, time remaining & lap time all added
- Cool intro screen!
- New track added: Castle Fields!
- 'Enemy' cars now less predicatable (but AI still being worked on)
- Lap records now saved
- GSlib has replaced many Dash routines for even more speed!
- Speed control now added as it runs way too fast on most machines. Speed 1 runs
  fastest, 9 is slowest.
- Removed sound as it was causing some problems
- Car no longer decelerates, so you can fix your speed better.

=================================================================================
'Ghini Run v0.7
Released 6 August 2000
- Ghini Run is unleashed upon an unsuspecting world!
==============================END OF TEXT FILE===================================